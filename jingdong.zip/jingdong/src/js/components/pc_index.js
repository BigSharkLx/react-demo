import React from 'react';
import {Row,Col}from 'antd';
import PCHeader from './pc_header.js';
import PCTopbody from './pc_topbody.js';
export default class PCIndex extends React.Component{
  render(){
    return(
      <div>
      <PCHeader/>
      <PCTopbody/>
      </div>
    );
  }
}
