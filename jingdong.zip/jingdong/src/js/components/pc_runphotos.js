// 仿京东轮播图组件
import React from 'react';
import {Row,Col,Icon}from 'antd';
export default class PCRunphotos extends React.Component{
  componentDidMount(){
    this.runphoto();
  }
  runphoto(){
    var timer=null;
    var indexNum=0;
    var photo=document.getElementsByClassName("photo");
    var len =photo.length;
    var arr=document.getElementById("arrow");
    var arrow=document.getElementById("arrow").getElementsByTagName("a");
    var dots=document.getElementById("dots").getElementsByTagName("span");
    // 遍历所有图片
    for(var everyphoto of photo){
      everyphoto.onmouseover=function(){
        // 鼠标滑入停止轮播
        clearInterval(timer);

        // 鼠标滑入显示前后导航图标
        arr.style.display="block";


      };

      everyphoto.onmouseout=function(){
        // 鼠标离开隐藏前后导航图标

        arr.style.display="none";

        // 鼠标离开自动轮播
        timer = setInterval(function(){
          indexNum++;
          if(indexNum==len){
            indexNum=0;
          }
          //  点击上一张
          arrow[0].onclick=function(){
            console.log(indexNum);
            indexNum--;
            if(indexNum<0){
              indexNum=len-1;
            }
            changePhoto();
          };
          //  点击下一张
          arrow[1].onclick=function(){
            indexNum++;
            if(indexNum==len){
              indexNum=0;
            }
            changePhoto();
          };
          //  下方导航按钮
          for(var i=0;i<len;i++){
            //  自定义属性记录当前的序列号
            dots[i].setAttribute("data-index", i);
            dots[i].onmouseover=function(){

                clearInterval(timer);
              //  鼠标滑过获得当前的序列号
              const index=this.getAttribute("data-index");
              // 将当前的序列号传递给图片序列号
              indexNum=index;
              changePhoto();
            };
          }
          changePhoto();
        },3000);

      };
    }
    // 手动添加鼠标滑过离开事件
    everyphoto.onmouseout();

    // 前后导航滑过显示
    arr.onmouseover=function(){
      arr.style.display="block";
    };
    // 图片切换函数
    function changePhoto(){
      for(var all of photo){
        all.style.display="none";
        photo[indexNum].style.display="block";
      }
      for(var d of dots){
        d.style.backgroundColor="#fff";
        dots[indexNum].style.backgroundColor="red";
      }
    }
  }
  render(){
    return(
      <div class="p_container">
      <ul class="ul_photo">
      <li><a class="photo image_1"><img src="./src/images/photo_1.jpg"/></a></li>
      <li><a class="photo image_2"><img src="./src/images/photo_2.jpg"/></a></li>
      <li><a class="photo image_3"><img src="./src/images/photo_3.jpg"/></a></li>
      <li><a class="photo image_4"><img src="./src/images/photo_4.jpg"/></a></li>
      <li><a class="photo image_5"><img src="./src/images/photo_5.jpg"/></a></li>
      <li><a class="photo image_6"><img src="./src/images/photo_6.jpg"/></a></li>
      <li><a class="photo image_7"><img src="./src/images/photo_7.jpg"/></a></li>
      <li><a class="photo image_8"><img src="./src/images/photo_8.jpg"/></a></li>
      </ul>
      <div class="arrow" id="arrow">
      <a class="prev"> <Icon type="left" /></a>
      <a class="next"><Icon type="right" /></a>
      </div>
      <div class="dots" id="dots">
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      <span></span>
      </div>
      <div class="otherimages">
      <a class="left"><img src="./src/images/left.png"/></a>
      <a class="right"><img src="./src/images/right.jpg"/></a>
      </div>
      </div>
    );
  }
}
