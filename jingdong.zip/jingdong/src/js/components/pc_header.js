import React from 'react';
import {Row,Col}from 'antd';
import { Menu, Icon,Dropdown,Popover,Badge } from 'antd';
const SubMenu = Menu.SubMenu;
const MenuItemGroup = Menu.ItemGroup;
export default class PCHeader extends React.Component{
  constructor(){
    super();
    this.state={
      cityName:'北京'
    };
  }
  cityChange(e){
    e.preventDefault();
    const tbody= document.getElementById("tbody");
    const a= tbody.getElementsByTagName("a");
    for(var i of a){
      i.className='';
      i.id='';
    }
    e.target.id="city_active";
    this.setState({cityName: e.target.innerHTML});
  }
  placeholderMiss(e){
    e.preventDefault();
    e.target.placeholder="";
  }
  placeholderAppear(e){
    e.preventDefault();
    e.target.placeholder="洗衣液";
  }
  hidden(){
    const header=document.getElementById("header");
    header.className="hidden";
  }
  render(){
    const contentCity=(
      <div class="city">
      <div id="tbody"
      onClick={this.cityChange.bind(this)}>
      <a>北京</a><a>上海</a><a>天津</a><a>重庆</a><a>河北</a>
      <a>山西</a><a>河南</a><a>辽宁</a><a>吉林</a><a>黑龙江</a>
      <a>内蒙古</a><a>江苏</a><a>山东</a><a>安徽</a><a>浙江</a>
      <a>福建</a><a>湖北</a><a>湖南</a><a>广东</a><a>广西</a>
      <a>江西</a><a>四川</a><a>海南</a><a>贵州</a><a>云南</a>
      <a>西藏</a><a>陕西</a><a>甘肃</a><a>青海</a><a>宁夏</a>
      <a>新疆</a><a>港澳</a><a>台湾</a><a>钓鱼岛</a><a>海外</a>
      </div>
      </div>
    );
    const contentjingdong=(
      <div class="jingdong">
      <a target="_blank"  href="//order.jd.com/center/list.action">待处理订单</a>
      <a target="_blank"  href="//joycenter.jd.com/msgCenter/queryHistoryMessage.action">消息</a>
      <a target="_blank"  href="//myjd.jd.com/afs/indexNew.action?entry=1">返修退换货</a>
      <a target="_blank"  href="http://question.jd.com/myjd/getMyjdAnswerList.action">我的问答</a>
      <a target="_blank"  href="//t.jd.com/product/followProductList.action?isReduce=true">降价商品</a>
      <a target="_blank"  href="//t.jd.com/home/follow">我的关注</a>
      <div class="hr_row"></div>
      <a target="_blank"  href="//t.jd.com/home/follow">我的京豆</a>
      <a target="_blank"  href="//quan.jd.com/user_quan.action">我的优惠券</a>
      <a target="_blank"  href="//baitiao.jd.com/">我的白条</a>
      <a target="_blank"  href="//trade.jr.jd.com/centre/browse.action">我的理财</a>
      </div>
    );
    const contentserver=(
      <div class="server">
      <dl class="customer">
      <dt>客户</dt>
      <dd>
      <a target="_blank" href="//help.jd.com/index.html">帮助中心</a>
      <a target="_blank" href="//myjd.jd.com/afs/indexNew.action?entry=2">售后服务</a>
      <a target="_blank" href="//chat.jd.com/jdchat/custom.action ">在线客服</a>
      <a target="_blank" href="//myjd-crm.jd.com/opinion/orderList.action">意见建议</a>
      <a target="_blank" href="//myjd-crm.jd.com/appoint/telebooking.action">电话客服</a>
      <a target="_blank" href="//www.jd.com/contact/service.html">客服邮箱</a>
      <a target="_blank" href="https://jrhelp.jd.com/">金融咨询</a>
      </dd>
      </dl>
      <div class="hr_row"></div>
      <dl class="businesser">
      <dt>商户</dt>
      <dd>
      <a target="_blank" href="//vc.jd.com/cooperation.html ">合作招商</a>
      <a target="_blank" href="//xue.jd.com/">京东商学院</a>
      </dd>
      </dl>
      </div>
    );
    const contentwebnav=(
      <div class="webnav">
      <dl class="fore1">
      <dt>特色主题</dt>
      <dd>
      <a href="//brands.jd.com/" target="_blank">品牌头条</a>
      <a href="//hao.jd.com/" target="_blank">发现好货</a>
      <a href="//xinpin.jd.com/presale.html " target="_blank">京东预售</a>
      <a href="//zan.jd.com" target="_blank">尖er货</a><a href="//try.jd.com/" target="_blank">京东试用</a>
      <a href="//coll.jd.com/list.html?sub=11461" target="_blank">港澳售</a>
      <a href="//a.jd.com/" target="_blank">优惠券</a>
      <a href="//red.jd.com/" target="_blank">闪购</a>
      <a href="//vip.jd.com/" target="_blank">京东会员</a>
      <a href="//miaosha.jd.com/" target="_blank">秒杀</a>
      <a href="//ding.jd.com/" target="_blank">定期送</a>
      <a href="//diy.jd.com/" target="_blank">装机大师</a>
      <a href="//hao.jd.com/hwy.html" target="_blank">新奇特</a>
      <a href="https://ft.jd.com/html/index/" target="_blank">企业金融服务</a>
      <a href="//gift.jd.com/" target="_blank">礼品购</a>
      <a href="//smarthome.jd.com/" target="_blank">智能馆</a>
      <a href=" https://pingce.jd.com/index.html" target="_blank">0元评测</a>
      <a href="//jr.jd.com/buy/index" target="_blank">In货推荐</a>
      <a href="//sale.jd.com/act/3je8ZTCxNl6SusId.html " target="_blank">北京老字号</a>
      <a href="//what.jd.com/" target="_blank">买什么</a>
      </dd>
      </dl>
      <div class="hr_col"></div>
      <dl class="fore2">
      <dt>行业频道</dt>
      <dd>
      <a href="//channel.jd.com/fashion.html" target="_blank">服装城</a>
      <a href="//channel.jd.com/electronic.html" target="_blank">家用电器</a>
      <a href="//diannao.jd.com/" target="_blank">电脑办公</a>
      <a href="//shouji.jd.com/" target="_blank">手机</a>
      <a href="//channel.jd.com/beauty.html" target="_blank">美妆馆</a>
      <a href="//channel.jd.com/chaoshi.html" target="_blank">食品</a>
      <a href="https://shuma.jd.com/" target="_blank">智能数码</a>
      <a href="//baby.jd.com/" target="_blank">母婴</a>
      <a href="//channel.jd.com/jiazhuang.html" target="_blank">家装城</a>
      <a href="//channel.jd.com/sports.html" target="_blank">运动户外</a>
      <a href="http://car.jd.com" target="_blank">整车</a>
      <a href="//book.jd.com/" target="_blank">图书</a>
      <a href="//nong.jd.com/" target="_blank">农资频道</a>
      <a href="//smart.jd.com/" target="_blank">京东智能</a>
      <a href="//3c.jd.com/" target="_blank">玩3C</a>
      </dd>
      </dl>
      <div class="hr_col"></div>
      <dl class="fore3">
      <dt>生活服务</dt>
      <dd>
      <a href="//z.jd.com/" target="_blank">京东众筹</a>
      <a href="//baitiao.jd.com/activity/third" target="_blank">白条</a>
      <a href="//m.jr.jd.com/helppage/downApp/jrAppPromote.html" target="_blank">京东金融APP</a>
      <a href="//trade.jr.jd.com/myxjk/jrbincome.action" target="_blank">京东小金库</a>
      <a href="//licai.jd.com/" target="_blank">理财</a>
      <a href="//chongzhi.jd.com/" target="_blank">话费</a>
      <a href="//trip.jd.com/" target="_blank">旅行</a>
      <a href="//caipiao.jd.com/" target="_blank">彩票</a>
      <a href="//game.jd.com/" target="_blank">游戏</a>
      <a href="//jipiao.jd.com/" target="_blank">机票酒店</a>
      <a href="//movie.jd.com/" target="_blank">电影票</a>
      <a href="//jiaofei.jd.com/" target="_blank">水电煤</a>
      <a href="//daojia.jd.com/html/welcome.html" target="_blank">京东到家</a>
      <a href="//smartcloud.jd.com/app" target="_blank">京东微联</a>
      <a href="//try-smart.jd.com/" target="_blank">京东众测</a>
      </dd>
      </dl>
      <div class="hr_col"></div>
      <dl class="fore4">
      <dt>更多精选</dt>
      <dd>
      <a href="http://group.jd.com" target="_blank">京东社区</a>
      <a href="//mobile.jd.com/index.do" target="_blank">京东通信</a>
      <a href="//read.jd.com/" target="_blank">在线读书</a>
      <a href="//o.jd.com/market/index.action" target="_blank">京东E卡</a>
      <a href="http://group.jd.com/site/20000121/20000032.htm" target="_blank">智能社区</a>
      <a href="http://group.jd.com/index/20000001.htm" target="_blank">游戏社区</a>
      <a href="//you.jd.com/index.html?entrance=jd_home" target="_blank">京友邦</a>
      <a href="//vc.jd.com/cooperation.html " target="_blank">合作招商</a>
      <a href="//b.jd.com/" target="_blank">企业采购</a><a href="//fw.jd.com/" target="_blank">服务市场</a>
      <a href="//zhaomu.jd.com/XCDLzm.html" target="_blank">乡村招募</a>
      <a href="//zhaomu.jd.com/intro.html" target="_blank">校园加盟</a>
      <a href="//channel.jd.com/office.html" target="_blank">办公生活馆</a>
      <a href="//ipr.jd.com/edition" target="_blank">知识产权维权</a>
      <a href="//en.jd.com/" target="_blank">English Site</a>
      </dd>
      </dl>
      </div>
    );
    return(
      <div>
      <Row>
      <header class="header" id="header">
      <Col span={2}/>
      <Col span={20}>
      <a class="header_a" target="_blank" href="//c-nfa.jd.com/adclick?keyStr=6PQwtwh0f06syGHwQVvRO7pzzm8GVdWoLPSzhvezmOXOQ+tKmOXwW7vEUuH11rSZj+qRobwW9z/wqLI/Zx1NOsx8ut2AZ9pRLazaqkbbvqGm6GuuDokoq6PWGVjHdOgBajK7SJxBAu/4FlX2X9wrehk979SobYL1reYGamG0+8WOdIgW2vGRfjGRhtC8dWIIYqcW0HquGvFY7UymRwwblKhFRI51vnrOu20t+Xy80EVym2vSmgk0pmt94y+5ZGmW/htFu0NCyHNZ8xfKp3JDHI2uY/XBEMs2Whg4vjrOTpikaAP1/sMPzQkjY4GquCJk&cv=2.0&url=//tob.jd.com/vote.html"></a>
      </Col>
      <Col span={2}><Icon class="close"
      onClick={this.hidden.bind(this)} type="close-square-o" /></Col>
      </header>
      </Row>
      <Row>
      <div class="header_nav">
      <Col span={2} />
      <Col span={3}>

      <a href="#">
      <div class="image">
      </div>
      </a>

      </Col>

      <Col span={17}>
      <div class="header_main">
      <div class="header_address">
      <Popover placement="bottomLeft" content={contentCity}>
      <span class="city_name"><Icon type="environment" />{this.state.cityName}</span>
      </Popover>
      </div>
      <div class="header_top">
      <a href="https://passport.jd.com/new/login.aspx?ReturnUrl=https%3A%2F%2Fwww.jd.com%2F%3Fcu%3Dtrue%26utm_source%3Dbaidu-pinzhuan%26utm_medium%3Dcpc%26utm_campaign%3Dt_288551095_baidupinzhuan%26utm_term%3D0f3d30c8dba7459bb52f2eb5eba8ac7d_0_46fdc9e821e74f42ae80298a6f7c74b0" target="_blank">您好！请登录</a>
      <a class="red" target="_blank" href="https://reg.jd.com/reg/person?ReturnUrl=https%3A//www.jd.com/">免费注册</a>
      <div class="spacer"></div>
      <a target="_blank" href="//order.jd.com/center/list.action">我的订单</a>
      <div class="spacer"></div>
      <Popover placement="bottomLeft" content={contentjingdong}>
      <a target="_blank" href="//home.jd.com/">我的京东<Icon type="down" /></a>
      </Popover>
      <div class="spacer"></div>
      <a target="_blank" href="//vip.jd.com/">京东会员</a>
      <div class="spacer"></div>
      <a target="_blank" href="//b.jd.com/">企业采购</a>
      <div class="spacer"></div>
      <Popover placement="bottomRight" content={contentserver}>
      <a>客户服务<Icon type="down" /></a>
      </Popover>
        <div class="spacer"></div>
      <Popover placement="bottom" content={contentwebnav}>
      <a>网站导航<Icon type="down" /></a>
      </Popover>
      <div class="spacer"></div>
      <a>手机京东</a>
      </div>
      </div>
      <div class="serch">
      <input class="input" type="text" placeholder="洗衣液" onFocus={this.placeholderMiss.bind(this)}   onBlur={this.placeholderAppear.bind(this)} >
      </input>
      <button type="submit">
      <Icon type="search" />
      </button>
      </div>
      <div class="buy">
      <Badge count={0} showZero>
      <a target="_blank" href="//cart.jd.com/cart.action">
      <Icon type="shopping-cart" />我的购物车</a>
      </Badge>
      </div>
      <div class="serchNav">
      <a href="//sale.jd.com/act/hSdesBfEyM.html?spm=1.1.0" target="_blank">买一送一</a>
      <a href="https://phone.jd.com/?spm=1.1.1" target="_blank">京选卖家</a>
      <a href="https://sale.jd.com/act/SRq0OcBzFID6MoNa.html?spm=1.1.2" target="_blank">农耕节</a>
      <a href="https://sale.jd.com/act/c7SUxNFa8njweoE.html?spm=1.1.3" target="_blank">男装品类日</a>
      <a href="//sale.jd.com/act/5Hz2J7blrFCfA.html?spm=1.1.4" target="_blank">领券狂减</a>
      <a href="//search.jd.com/Search?keyword=%E9%BC%A0%E6%A0%87&enc=utf-8&spm=1.1.5" target="_blank">鼠标</a>
      <a href="//search.jd.com/Search?keyword=%E8%A1%AC%E8%A1%AB%E7%94%B7%E9%95%BF%E8%A2%96&enc=utf-8&spm=1.1.6" target="_blank">衬衫男长袖</a>
      <a href="https://sale.jd.com/act/T1XJujgMEf.html?spm=1.1.7" target="_blank">199减100</a>
      <a href="//search.jd.com/Search?keyword=%E7%94%B5%E7%81%AB%E9%94%85&enc=utf-8&spm=1.1.8" target="_blank">电火锅</a>
      </div>
      <div class="main_nav">
      <div class="nav_item"><a href="//miaosha.jd.com/" target="_blank">秒杀</a></div>
      <div class="nav_item"><a href="https://a.jd.com/" target="_blank">优惠券</a></div>
      <div class="nav_item"><a href="//red.jd.com/" target="_blank">闪购</a></div>
      <div class="nav_item"><a href="//paimai.jd.com/" target="_blank">拍卖</a></div>
      <div class="hr_col"></div>
      <div class="nav_item"><a href="https://channel.jd.com/fashion.html " target="_blank">服装城</a></div>
      <div class="nav_item"><a href="//chaoshi.jd.com/" target="_blank">京东超市</a></div>
      <div class="nav_item"><a href="//fresh.jd.com/" target="_blank">生鲜</a></div>
      <div class="nav_item"><a href="//www.jd.hk/" target="_blank">全球购</a></div>
      <div class="hr_col"></div>
      <div class="nav_item"><a href="//jr.jd.com/" target="_blank">京东金融</a></div>
      </div>
      </Col>
      <Col span={2}/>
      </div>
      </Row>
      </div>
    );
  }
}
